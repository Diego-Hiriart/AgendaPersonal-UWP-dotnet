﻿namespace Hiriart_Corales_UWPApp_AgendaPersonal.Behaviors
{
    public enum NavigationViewHeaderMode
    {
        Always,
        Never,
        Minimal
    }
}
